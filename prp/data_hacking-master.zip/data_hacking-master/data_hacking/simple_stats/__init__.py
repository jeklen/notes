'''Package for the Simple Statistical Functionality'''
from simple_stats import *

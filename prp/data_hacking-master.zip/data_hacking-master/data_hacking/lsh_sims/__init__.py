'''Package for the LSH (Locality Sensitive Hashing) Module'''
from lsh_sims import *

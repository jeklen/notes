'''Package for the HCluster (Hierarchical Clustering) Module'''
from hcluster import *

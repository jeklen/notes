'''Package for Banded Min Hash based Similarity Calculations'''
from min_hash import *
